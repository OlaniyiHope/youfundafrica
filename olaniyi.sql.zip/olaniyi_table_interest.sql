
-- --------------------------------------------------------

--
-- Table structure for table `interest`
--

CREATE TABLE `interest` (
  `interestId` int(255) NOT NULL,
  `majorinterest` varchar(255) NOT NULL,
  `addinterest` varchar(255) NOT NULL,
  `biointerest` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `interest`
--

INSERT INTO `interest` (`interestId`, `majorinterest`, `addinterest`, `biointerest`) VALUES
(1, '', '', ''),
(2, '', '', ''),
(3, '', '', ''),
(4, '', '', '');
