
-- --------------------------------------------------------

--
-- Table structure for table `myinterest`
--

CREATE TABLE `myinterest` (
  `interestId` int(200) NOT NULL,
  `majorinterest` varchar(170) NOT NULL,
  `addinterest` varchar(200) NOT NULL,
  `biointerest` varchar(220) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `myinterest`
--

INSERT INTO `myinterest` (`interestId`, `majorinterest`, `addinterest`, `biointerest`) VALUES
(1, '', '', '');
