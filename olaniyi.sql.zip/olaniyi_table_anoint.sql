
-- --------------------------------------------------------

--
-- Table structure for table `anoint`
--

CREATE TABLE `anoint` (
  `id` int(20) NOT NULL,
  `majorinterest` varchar(190) NOT NULL,
  `addinterest` varchar(160) NOT NULL,
  `biointerest` varchar(200) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `anoint`
--

INSERT INTO `anoint` (`id`, `majorinterest`, `addinterest`, `biointerest`) VALUES
(1, '', '', ''),
(2, '', '', ''),
(3, '', '', ''),
(4, '', '', ''),
(5, '', '', ''),
(6, '', '', ''),
(7, 'Education', 'h', 'ik'),
(8, 'Agriculture', 'vid', 'vid'),
(9, 'Agriculture', 'bisi', 'bisi'),
(10, 'Education', 'agric', 'hh'),
(11, 'Education', 'Technology', 'Iys ');
