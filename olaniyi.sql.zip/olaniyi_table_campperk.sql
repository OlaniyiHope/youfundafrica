
-- --------------------------------------------------------

--
-- Table structure for table `campperk`
--

CREATE TABLE `campperk` (
  `id` int(200) NOT NULL,
  `title` varchar(170) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `campperk`
--

INSERT INTO `campperk` (`id`, `title`) VALUES
(1, ''),
(2, 'jgy'),
(3, 'Content');
